package com.rohit.day3;

public class NegativeNumberException extends RuntimeException{
	
	public NegativeNumberException(String message) {
		super(message);
	}
}
