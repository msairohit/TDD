package com.rohit.day3;

import java.util.ArrayList;
import java.util.List;

public class StringCalculator {

	public int add(String string) {
		int result = 0;
		if(string.isEmpty())
			result = 0;
		else 
			result = Integer.parseInt(string);
		return result;
	}
	
	public int calculate(String string) throws NegativeNumberException {
		String[] numbers = new String[2];
		List<Integer> negativeNumbers = new ArrayList<>(); 
//		int [] negativeNumbers = new int[10];
		int sum = 0;
		numbers = string.split(",|\n");
		for(String number : numbers) {
					if(Integer.parseInt(number) < 0)
						negativeNumbers.add(Integer.parseInt(number));
				sum += add(number);
			}
		if(!negativeNumbers.isEmpty()) {
			throw new NegativeNumberException("negatives not allowed" + negativeNumbers.toString());
		}
		return sum;
		
	}

}
