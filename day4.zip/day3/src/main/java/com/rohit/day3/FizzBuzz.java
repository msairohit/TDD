package com.rohit.day3;

public class FizzBuzz {

	public static String checkNumber(int number) {
		String result = String.valueOf(number);
		if(isNumberDivisibleBy3(number)) 
			result = "Fizz";
		if(isNumberDivisibleBy5(number)) 
			result = "Buzz";
		if(isMultipleOf3And5(number))
			result = "FizzBuzz";
		
		return result;
	}

	private static boolean isNumberDivisibleBy5(int number) {
		return number % 5 == 0;
	}

	private static boolean isNumberDivisibleBy3(int number) {
		return number % 3 == 0;
	}

	private static boolean isMultipleOf3And5(int number) {
		return (number % 3 == 0) && isNumberDivisibleBy5(number);
	}

}
