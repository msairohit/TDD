package com.rohit.day4;

import java.util.ArrayList;
import java.util.List;

public class HarryPotterBooks {

	public double getCost(List<Book> books) {
		double price = 0.0;
		List<Book> uniqueBooks = new ArrayList<>();
		if (containsMoreThanOneBook(books)) {
			while (bookListIsNotEmpty(books)) {
				uniqueBooks = createUniqueBookList(books, uniqueBooks);
				price += calculatePriceForDifferentBooks(uniqueBooks);
				uniqueBooks.clear();
			}
			return price;
		}

		return books.size() * 8;
	}

	private List<Book> createUniqueBookList(List<Book> books, List<Book> uniqueBooks) {
		for (int i = 0; i < books.size(); i++) {
			if (isCurrentBookNotUnique(books, uniqueBooks, i)) {
				uniqueBooks.add(books.get(i));
				books.remove(books.get(i));
				i--;
			}
		}
		return uniqueBooks;
	}

	private boolean isCurrentBookNotUnique(List<Book> books, List<Book> uniqueBooks, int i) {
		return !uniqueBooks.contains(books.get(i));
	}

	private boolean bookListIsNotEmpty(List<Book> books) {
		return !books.isEmpty();
	}

	private boolean containsMoreThanOneBook(List<Book> books) {
		return books.size() > 1;
	}

	public double calculatePriceForDifferentBooks(List<Book> books) {
		double percentage = 0;
		double originalPrice = books.size() * 8.0;
		switch (books.size()) {
		case 2:
			percentage = 5;
			break;
		case 3:
			percentage = 10;
			break;
		case 4:
			percentage = 20;
			break;
		case 5:
			percentage = 25;
			break;
		default:
			percentage = 0;
		}
		return originalPrice - (originalPrice * (percentage / 100));
	}

}