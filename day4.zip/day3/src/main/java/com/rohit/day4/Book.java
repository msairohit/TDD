package com.rohit.day4;

public enum Book {
	BOOK1,BOOK2,BOOK3,BOOK4,BOOK5
}
