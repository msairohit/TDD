package com.rohit.day4;

import java.util.List;

public class DigitalNumberDisplay {

	private String [] digitalRepresentation = new String[] 
			{       "._.\n|.|\n|_|",
					"...\n..|\n..|",
					"._.\n._|\n|_.",
					"._.\n._|\n._|",
					"...\n|_|\n..|",
					"._.\n|_.\n._|",
					"._.\n|_.\n|_|",
					"._.\n..|\n..|",
					"._.\n|_|\n|_|",
					"._.\n|_|\n..|"
			};
	public String print(int number) {
		return digitalRepresentation[number];
	}
	
	public String print(List<Integer> number) {
		String result = "";
		int i = 0;
		do {
		for(Integer digit : number) {
			result += digitalRepresentation[digit].split("\n")[i];
		}
		result += "\n";
		i++;
		}while(i<3);
		result = result.trim();
		return result;
	}
	
}
