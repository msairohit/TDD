package com.rohit.day4;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

import com.rohit.day4.Book;
import com.rohit.day4.HarryPotterBooks;

public class HarryPotterBooksTest {

	private static final double DELTA = 0.0;
	HarryPotterBooks harryPotter = new HarryPotterBooks();

	@Test
	public void testWhenSingleBookIsOrdered() {
		List<Book> books = new ArrayList<>();
		books.add(Book.BOOK1);
		assertEquals(8.0, harryPotter.getCost(books), DELTA);
	}
	
	@Test
	public void testWhenTwoSameBooksAreOrdered() {
		List<Book> books = new ArrayList<>();
		books.add(Book.BOOK1);
		books.add(Book.BOOK1);
		assertEquals(16.0, harryPotter.getCost(books), DELTA);
	}

	@Test
	public void testWhenTwoDifferentBooksAreOrdered() {
		List<Book> books = new ArrayList<>();
		books.add(Book.BOOK1);
		books.add(Book.BOOK2);
		assertEquals(15.2, harryPotter.getCost(books), DELTA);
	}
	
	@Test
	public void testWhenThreeDifferentBooksAreOrdered() {
		List<Book> books = new ArrayList<>();
		books.add(Book.BOOK1);
		books.add(Book.BOOK2);
		books.add(Book.BOOK5);
		assertEquals(21.6, harryPotter.getCost(books), DELTA);
	}
	
	@Test
	public void testWhenHybridBooksAreOrdered() {
		List<Book> books = new ArrayList<>();
		books.add(Book.BOOK1);
		books.add(Book.BOOK2);
		books.add(Book.BOOK3);
		books.add(Book.BOOK4);
		books.add(Book.BOOK5);
		books.add(Book.BOOK1);
		books.add(Book.BOOK2);
		books.add(Book.BOOK1);
		books.add(Book.BOOK1);
		books.add(Book.BOOK1);
		books.add(Book.BOOK1);
		assertEquals(77.2, harryPotter.getCost(books), DELTA);
	}
	
	@Test
	public void testWhenHybridBooksAreOrdered1() {
		List<Book> books = new ArrayList<>();
		books.add(Book.BOOK1);
		books.add(Book.BOOK1);
		books.add(Book.BOOK2);
		books.add(Book.BOOK2);
		books.add(Book.BOOK3);
		books.add(Book.BOOK3);
		books.add(Book.BOOK4);
		books.add(Book.BOOK5);
		assertEquals(51.6, harryPotter.getCost(books), DELTA);
	}

}