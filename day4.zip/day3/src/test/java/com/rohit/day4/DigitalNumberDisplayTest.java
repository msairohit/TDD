package com.rohit.day4;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.rohit.day4.DigitalNumberDisplay;

public class DigitalNumberDisplayTest {
	
	DigitalNumberDisplay digitalNumberDisplay = new DigitalNumberDisplay();
	
	@Before
	public void testDigitalNumberDisplayClass() {
		DigitalNumberDisplay digitalNumberDisplay = new DigitalNumberDisplay();
	}
	
	@Test
	public void testDigitalNumberDisplaywithInputZero() {
		assertEquals("._.\n|.|\n|_|", digitalNumberDisplay.print(0));
	}
	
	@Test
	public void testDigitalNumberDisplaywithInputOne() {
		assertEquals("...\n..|\n..|", digitalNumberDisplay.print(1));
	}
	
	@Test
	public void testDigitalNumberDisplaywithInputTwo() {
		assertEquals("._.\n._|\n|_.", digitalNumberDisplay.print(2));
	}
	
	@Test
	public void testDigitalNumberDisplaywithInputThree() {
		assertEquals("._.\n._|\n._|", digitalNumberDisplay.print(3));
	}
	
	@Test
	public void testDigitalNumberDisplaywithInputNine() {
		assertEquals("._.\n|_|\n..|", digitalNumberDisplay.print(9));
	}
	
	@Test
	public void testDigitalNumberDisplayWith2Digits10() {
		assertEquals("...._.", digitalNumberDisplay.print(Arrays.asList(1,0)).split("\n")[0]);
	}
	
	@Test
	public void testDigitalNumberDisplayWith4DigitsFirstRow() {
		assertEquals("...._.._.._.", digitalNumberDisplay.print(Arrays.asList(1,0,0,0)).split("\n")[0]);
	}
	
	@Test
	public void testDigitalNumberDisplayWith4DigitsSecondRow() {
		assertEquals("..||.||.||.|", digitalNumberDisplay.print(Arrays.asList(1,0,0,0)).split("\n")[1]);
	}
	
	@Test
	public void testDigitalNumberDisplayWith4DigitsThirdRow() {
		assertEquals("..||_||_||_|", digitalNumberDisplay.print(Arrays.asList(1,0,0,0)).split("\n")[2]);
	}
	
	@Test
	public void testDigitalNumberDisplayWith4DigitsAllRows() {
		String expected = "...._.._.._." + "\n" +
"..||.||.||.|" + "\n" +
"..||_||_||_|";
		assertEquals(expected, digitalNumberDisplay.print(Arrays.asList(1,0,0,0)));
	}
}
