package com.rohit.day3;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class FizzBuzzTest {
	
	private static final String FIZZ_BUZZ = "FizzBuzz";
	private static final String FIZZ = "Fizz";
	private static final String BUZZ = "Buzz";

	@Before
	public void fizzBuzzTest() {
		FizzBuzz fizzBuzz = new FizzBuzz();
	}
	
	@Test
	public void testShouldReturn1() {
		Assert.assertEquals("1", FizzBuzz.checkNumber(1));
	}
	
	@Test
	public void testShouldReturn2() {
		Assert.assertEquals("2", FizzBuzz.checkNumber(2));
	}
	
	@Test
	public void testShouldReturnFizzForNumber3() {
		Assert.assertEquals(FIZZ, FizzBuzz.checkNumber(3));
	}
	
	@Test
	public void testShouldReturn4() {
		Assert.assertEquals("4", FizzBuzz.checkNumber(4));
	}
	
	@Test
	public void testShouldReturnBuzzForNumber5() {
		Assert.assertEquals(BUZZ, FizzBuzz.checkNumber(5));
	}
	
	@Test
	public void testShouldReturn6() {
		Assert.assertEquals("Fizz", FizzBuzz.checkNumber(6));
	}
	
	@Test
	public void testShouldReturnFizzBuzzForNumber15() {
		Assert.assertEquals(FIZZ_BUZZ, FizzBuzz.checkNumber(15));
	}
	
	@Test
	public void testShouldReturn16() {
		Assert.assertEquals("16", FizzBuzz.checkNumber(16));
	}
	
}
