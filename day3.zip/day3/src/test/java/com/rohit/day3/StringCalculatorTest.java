package com.rohit.day3;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class StringCalculatorTest {

	StringCalculator stringCalculator = new StringCalculator();
	
	@Test
	public void testAddForEmptyString() {
		assertEquals(0, stringCalculator.add(""));
	}
	
	@Test
	public void testAddForOneDigit1() {
		assertEquals(1, stringCalculator.add("1"));
	}
	
	@Test
	public void testAddForOneDigit562() {
		assertEquals(562, stringCalculator.add("562"));
	}
	
	@Test
	public void testAddForTwoDigits() {
		assertEquals(10, stringCalculator.calculate("5,5"));
	}
	
	@Test
	public void testAddForMultipleDigits() {
		assertEquals(70, stringCalculator.calculate("5,5,5,55"));
	}
	
	@Test
	public void testAddForMultipleDelimiters() {
		assertEquals(77, stringCalculator.calculate("5,5\n6,5,55\n1"));
	}
	
	@Test(expected = RuntimeException.class)
	public void testAddForExceptionWhenNegativeNumberIsPassed() {
//		assertEquals(77, stringCalculator.calculate("5,-5"));
		stringCalculator.calculate("5,-5");
	}

}
